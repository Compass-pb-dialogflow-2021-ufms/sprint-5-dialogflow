function aboutMe()
{
    const text = 'Esse bot surgiu como uma demanda gerada por um exercício a ser realizado durante a quinta sprint do meu programa de bolsas na Compass UOL. A ideia do exercício é um bot que consegue mostrar para o usuário a previsão do tempo para um município brasileiro para os próximo 4 dias, sendo o nome do bot Maju.\n\n' + 
    'Quem fez ele -> O desenvolvedor responsável por esse bot foi o Horiel Corrêa Costa. No momento que ele fez, ele era um aluno de segundo semestre de faculdade e sua experiência profissional se resumia a 2 meses de estágio. Esse foi o quarto bot que ele fez, portanto, tenha paciência com a Maju :)'


    return text
}


module.exports = aboutMe