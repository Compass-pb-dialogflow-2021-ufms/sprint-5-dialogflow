function goodbye()
{
    const text = `Ok. Qualquer coisa é só mandar uma mensagem que terei o prazer de te ajudar novamente!`


    return text
}


module.exports = goodbye