function welcome()
{
    const text = `Olá, seja bem vindo. Eu sou a Maju.bot e posso te informar a previsão do tempo para os próximos 4 dias em qualquer município brasileiro! Voce gostaria de ver os dados meteorológicos de qual município?`

    return text
}


module.exports = welcome